var searchData=
[
  ['lis3dsh_5ferror_5fid_61',['LIS3DSH_ERROR_ID',['../lis3dsh_8h.html#af8c2055484b699e4d84679f0090e7e4ea262e430941156b333950dfc18869d5c8',1,'lis3dsh.h']]],
  ['lis3dsh_5ferror_5fnone_62',['LIS3DSH_ERROR_NONE',['../lis3dsh_8h.html#af8c2055484b699e4d84679f0090e7e4ea7a5a444d8e0684fd2345b8bf0af8c963',1,'lis3dsh.h']]],
  ['lis3dsh_5ferror_5fspi_63',['LIS3DSH_ERROR_SPI',['../lis3dsh_8h.html#af8c2055484b699e4d84679f0090e7e4ea3cabe71cafc0a48cbee38db05d24b8b6',1,'lis3dsh.h']]]
];
