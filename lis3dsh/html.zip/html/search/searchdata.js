var indexSectionsWithContent =
{
  0: "achlsxyz",
  1: "as",
  2: "l",
  3: "l",
  4: "hlxyz",
  5: "cl",
  6: "cl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Перечисления",
  6: "Элементы перечислений"
};

